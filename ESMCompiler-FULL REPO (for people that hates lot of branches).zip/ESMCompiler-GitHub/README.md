# ESMCompiler

Unreal Engine 5.8 Editor plugin and C++20 backend for compiling an engine-independent world model into a Skyrim SE/AE 1.6.1170 ESM.

The repository deliberately contains source, configuration, resources and plugin metadata only. It excludes `Binaries`, `Intermediate`, Visual Studio files and other generated artifacts.

## Current validated path

`UE5 Landscape -> World IR -> WRLD + exterior CELL + LAND -> ESM -> Creation Kit`

The current LAND MVP emits terrain height, normals, white vertex colors and a base LTEX layer. It has been opened and rendered by Creation Kit.

Not yet complete: static-object `REFR`, light `LIGH`, water, gameplay records, and production validation of additional texture-layer blending (`ATXT`/`VTXT`).

## Source layout

| Folder | Responsibility |
|---|---|
| `Private/Unreal` | UE5-only World Reader and export service. |
| `Private/UI` | Slate editor panel. |
| `Private/Backend/WorldIR` | Engine-independent world data and coordinate transform. |
| `Private/Backend/WRLD` | Logical WRLD model and serialization. |
| `Private/Backend/Cell` | Exterior-cell grid, allocation, records and group organization. |
| `Private/Backend/Land` | LAND IR, sampling, resampling, terrain encoders and serializer. |
| `Private/Backend/FormIDs` | AssetID parsing and master-relative FormID allocation/validation. |
| `Private/Backend/Core` | ESM binary/record/group writing and shared utilities. |
| `Private/Backend/Pipeline` | Backend compiler orchestration. |
| `Private/Backend/References` | Future REFR serialization foundation. |

`WorldIR` and all backend folders except `Unreal` are intentionally independent of Unreal types. Creation Engine binary code is isolated in record/serializer components.

## FormID contract

The MAST order selected in the UI determines the high byte of master references:

```text
MAST[0]  -> 00xxxxxx
MAST[1]  -> 01xxxxxx
...
Output ESM's new records -> <master count>xxxxxx
```

UE asset names are project-authored hexadecimal FormIDs. A base landscape material named `00013428`, for example, maps to LTEX `00013428` in `MAST[0]`. The compiler does not perform plugin lookup or asset-name inference.

## Opening as a UE plugin

Copy or clone this folder as `ESMCompiler` under either:

```text
<Project>/Plugins/ESMCompiler
```

or:

```text
<UE>/Engine/Plugins/Editor/ESMCompiler
```

Regenerate project files from the `.uproject` context if necessary, then build the project in the `Development Editor` configuration. `ESMCompiler.Build.cs` defines the include paths for the categorized backend folders.
