# Compiler architecture

```text
UE5 UWorld
  -> Private/Unreal/UEWorldReader
  -> Private/Backend/WorldIR
  -> Private/Backend/Pipeline
  -> WRLD + CELL + LAND logical records
  -> Private/Backend/Core binary writers
  -> .esm
```

## Dependency direction

`Unreal` is the only folder permitted to include UE5 classes such as `UWorld`, `ALandscape` or `UStaticMeshComponent`.

`WorldIR` is the boundary between the UE frontend and the compiler backend. It stores only standard C++ data types. Backend generation and serialization code must never include Unreal headers.

## Responsibilities

### UE frontend

- `IWorldReader`, `UEWorldReader`: read authoring data from the current `UWorld`.
- `ESMExportService`: bridges UE strings/UI requests to the backend.
- `UI`: Slate configuration panel and asynchronous compile progress.

### Backend foundation

- `Core`: binary output and TES4/GRUP/record framing.
- `FormIDs`: master-relative reference rules and new-record allocation.
- `WorldIR`: canonical data containers and coordinate transform.
- `Pipeline`: top-level orchestration only.

### Record domains

- `WRLD`: worldspace logical model and serializer.
- `Cell`: exterior CELL assignment, logical records and group plans.
- `Land`: height sampling/resampling, 33x33 LAND tiles, normals, vertex colors, texture planning and LAND serialization.
- `References`: future REFR support.

## Current output hierarchy

```text
TES4
└─ WRLD
   ├─ Persistent worldspace CELL foundation
   └─ Exterior CELL group
      └─ one CELL per coordinate
         └─ temporary child group
            └─ one LAND per complete terrain cell
```

The generated plugin's own FormIDs use the high byte equal to the MAST count. Example: one selected master (`Skyrim.esm`) means generated WRLD/CELL/LAND records use `01xxxxxx`; master references to Skyrim use `00xxxxxx`.
