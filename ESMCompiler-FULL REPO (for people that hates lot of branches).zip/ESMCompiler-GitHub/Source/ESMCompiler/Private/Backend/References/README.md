# References

Foundation for future object and light `REFR` serialization. It is not yet wired to generate placement records.
