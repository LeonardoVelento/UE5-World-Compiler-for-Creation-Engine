#include "ReferenceSerializer.h"

#include "RecordWriter.h"

void ReferenceSerializer::Serialize(const ReferenceRecord& record, BinaryWriter& writer) const {
    RecordHeader header{};
    header.recordType = {'R', 'E', 'F', 'R'};
    header.formID = record.formID;

    RecordWriter reference(writer, header);
    reference.Finalize();
}
