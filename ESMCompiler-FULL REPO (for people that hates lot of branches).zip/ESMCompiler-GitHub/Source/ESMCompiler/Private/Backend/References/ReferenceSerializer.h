#pragma once

#include "BinaryWriter.h"
#include "WorldspaceGroupPlan.h"

// MVP placeholder. It emits a REFR record header with no payload. A later REFR
// implementation will replace this with actual reference data serialization.
class ReferenceSerializer final {
public:
    void Serialize(const ReferenceRecord& record, BinaryWriter& writer) const;
};
