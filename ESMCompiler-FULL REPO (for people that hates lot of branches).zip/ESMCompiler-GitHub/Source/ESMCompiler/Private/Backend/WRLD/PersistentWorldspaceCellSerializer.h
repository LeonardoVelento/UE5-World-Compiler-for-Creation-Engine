#pragma once

#include "BinaryWriter.h"
#include "PersistentWorldspaceCellRecord.h"

// Explicit safety boundary: the logical persistent CELL is ready for the
// future REFR pipeline, but its CK-generated binary payload has not yet been
// fixture-verified. It must not be serialized speculatively.
class PersistentWorldspaceCellSerializer final {
public:
    void Serialize(const PersistentWorldspaceCellRecord& record, BinaryWriter& writer) const;
};