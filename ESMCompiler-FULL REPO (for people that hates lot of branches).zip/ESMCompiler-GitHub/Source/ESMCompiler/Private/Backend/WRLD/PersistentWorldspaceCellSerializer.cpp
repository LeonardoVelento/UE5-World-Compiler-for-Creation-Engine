#include "PersistentWorldspaceCellSerializer.h"

#include "MissingSpecification.h"

void PersistentWorldspaceCellSerializer::Serialize(
    const PersistentWorldspaceCellRecord& record,
    BinaryWriter& writer) const {
    static_cast<void>(record);
    static_cast<void>(writer);
    throw MissingSpecification(
        "Persistent worldspace CELL serialization requires a CK AE 1.6.1170 fixture and is not implemented.");
}