#pragma once

#include <cstdint>
#include <optional>
#include <string>

using RecordFormID = std::uint32_t;

enum class WorldFlags : std::uint32_t {
    Default = 0,
};

// Reserved logical container for optional WRLD map data.
// Its contents are intentionally unspecified until map-data generation is implemented.
struct WRLDMapData {};

// Logical Creation Engine WRLD record. This class does not serialize itself.
class WRLDRecord final {
public:
    WRLDRecord();

    std::string editorID;
    std::string fullName;
    std::optional<RecordFormID> parentWorld;
    WorldFlags worldFlags;
    std::optional<RecordFormID> climate;
    std::optional<RecordFormID> water;
    std::optional<WRLDMapData> mapData;
};
