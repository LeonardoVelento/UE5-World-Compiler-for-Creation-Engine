#pragma once

#include <cstdint>

// Logical identity for Skyrim's single worldspace-persistent CELL.
// It is deliberately distinct from ExteriorCellRecord: it has no LAND and
// does not belong to an exterior block/sub-block.
//
// The future REFR generator allocates this record only when persistent
// references need it. No binary CELL payload is specified here.
struct PersistentWorldspaceCellRecord {
    std::uint32_t formID = 0;
    std::uint16_t flags = 0;
};