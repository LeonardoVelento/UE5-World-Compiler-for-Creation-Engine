# WRLD

Logical WRLD record model, World IR to WRLD generation, serialization and persistent-worldspace CELL foundation.
