#pragma once

#include "CellGrid.h"
#include "ExteriorCellRecord.h"
#include "LandRecord.h"

#include <cstdint>
#include <vector>

// Temporary compiler-side REFR link model. It intentionally contains only
// information required for CELL linking and will be replaced by the full REFR
// logical model when REFR generation is implemented.
enum class ObjectReferencePersistence {
    Temporary,
    Persistent,
};

struct GeneratedObjectReferenceRecord {
    std::uint32_t formID;
    CellCoordinates cellCoordinates;
    ObjectReferencePersistence persistence = ObjectReferencePersistence::Temporary;
};

// Links already-generated logical REFR and LAND records to logical exterior
// CELL records. It never allocates IDs, generates records, or serializes data.
class CellContentLinker final {
public:
    void Link(const CellGrid& grid,
              std::vector<ExteriorCellRecord>& cellRecords,
              const std::vector<GeneratedObjectReferenceRecord>& objectReferenceRecords,
              const std::vector<LandRecord>& landRecords) const;
};
