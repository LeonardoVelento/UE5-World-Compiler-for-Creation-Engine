#include "GroupWriter.h"

#include <limits>
#include <stdexcept>

GroupWriter::GroupWriter(BinaryWriter& writer, const GroupHeader& header)
    : writer_(writer)
    , groupStart_(writer_.Tell()) {
    writer_.WriteBytes("GRUP", 4);

    groupSizePosition_ = writer_.Tell();
    writer_.WriteUInt32(0);
    writer_.WriteBytes(header.label.data(), header.label.size());
    writer_.WriteInt32(header.groupType);
    writer_.WriteUInt16(header.stamp);
    writer_.WriteUInt16(header.unknown);
    writer_.WriteUInt16(header.version);
    writer_.WriteUInt16(header.unknown2);
}

GroupWriter::~GroupWriter() noexcept {
    FinalizeNoexcept();
}

void GroupWriter::Finalize() {
    if (finalized_) {
        return;
    }

    const std::streampos groupEnd = writer_.Tell();
    const std::streamoff groupSize = groupEnd - groupStart_;
    if (groupSize < 0) {
        throw std::logic_error("GroupWriter group end precedes its start.");
    }

    if (static_cast<std::uintmax_t>(groupSize) > std::numeric_limits<std::uint32_t>::max()) {
        throw std::length_error("GroupWriter group exceeds the 32-bit size field.");
    }

    writer_.Seek(groupSizePosition_);
    writer_.WriteUInt32(static_cast<std::uint32_t>(groupSize));

    finalized_ = true;
    writer_.Seek(groupEnd);
}

bool GroupWriter::IsFinalized() const noexcept {
    return finalized_;
}

void GroupWriter::FinalizeNoexcept() noexcept {
    if (finalized_) {
        return;
    }

    try {
        Finalize();
    } catch (...) {
        // Destructors cannot safely propagate an I/O error during stack unwinding.
    }
}
