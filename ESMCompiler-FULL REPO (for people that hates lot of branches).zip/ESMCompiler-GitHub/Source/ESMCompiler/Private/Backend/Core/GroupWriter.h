#pragma once

#include "BinaryWriter.h"

#include <array>
#include <cstdint>
#include <ios>

// Header for a Creation Engine GRUP container.
struct GroupHeader {
    std::array<char, 4> label{};
    std::int32_t groupType = 0;
    std::uint16_t stamp = 0;
    std::uint16_t unknown = 0;
    std::uint16_t version = 0;
    std::uint16_t unknown2 = 0;
};

// Owns an in-progress GRUP. Its total size is backpatched on finalization.
class [[nodiscard("A GroupWriter must remain alive while writing its contents.")]] GroupWriter final {
public:
    GroupWriter(BinaryWriter& writer, const GroupHeader& header);
    ~GroupWriter() noexcept;

    GroupWriter(const GroupWriter&) = delete;
    GroupWriter& operator=(const GroupWriter&) = delete;
    GroupWriter(GroupWriter&&) = delete;
    GroupWriter& operator=(GroupWriter&&) = delete;

    void Finalize();
    [[nodiscard]] bool IsFinalized() const noexcept;

private:
    void FinalizeNoexcept() noexcept;

    BinaryWriter& writer_;
    std::streampos groupStart_;
    std::streampos groupSizePosition_;
    bool finalized_ = false;
};
